const car = require('./car_module');

car.drive();
car.turn();
car.break();